import React from 'react';
import { Transaction, Settings } from '../types';
import { ArrowLeft, Printer, Download } from 'lucide-react';
import { formatCurrency } from '../utils/currency';

interface ReceiptProps {
  transaction: Transaction;
  settings: Settings;
  onNewSale: () => void;
}

export const Receipt: React.FC<ReceiptProps> = ({ transaction, settings, onNewSale }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-lg shadow-md max-w-2xl mx-auto">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-800">Receipt</h2>
        <div className="flex gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Printer className="w-4 h-4" />
            Print
          </button>
          <button
            onClick={() => {/* Download functionality */}}
            className="flex items-center gap-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            Download
          </button>
        </div>
      </div>

      <div className="p-6" id="receipt-content">
        {/* Store Header */}
        <div className="text-center mb-6 border-b border-gray-200 pb-4">
          <h1 className="text-2xl font-bold text-gray-800">{settings.businessInfo.name}</h1>
          <p className="text-gray-600">{settings.businessInfo.address}</p>
          <p className="text-gray-600">Phone: {settings.businessInfo.phone}</p>
          {settings.businessInfo.gstNo && (
            <p className="text-gray-600">GST No: {settings.businessInfo.gstNo}</p>
          )}
        </div>

        {/* Transaction Details */}
        <div className="mb-6 text-sm">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p><strong>Transaction ID:</strong> {transaction.id}</p>
              <p><strong>Date:</strong> {transaction.timestamp.toLocaleDateString()}</p>
              <p><strong>Time:</strong> {transaction.timestamp.toLocaleTimeString()}</p>
            </div>
            <div>
              <p><strong>Payment Method:</strong> {transaction.paymentMethod.toUpperCase()}</p>
              {transaction.customerName && (
                <p><strong>Customer:</strong> {transaction.customerName}</p>
              )}
            </div>
          </div>
        </div>

        {/* Items */}
        <div className="mb-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="text-left py-2">Item</th>
                <th className="text-center py-2">Qty</th>
                <th className="text-right py-2">Price</th>
                <th className="text-right py-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {transaction.items.map((item) => (
                <tr key={item.product.id} className="border-b border-gray-100">
                  <td className="py-2">{item.product.name}</td>
                  <td className="text-center py-2">{item.quantity}</td>
                  <td className="text-right py-2">{formatCurrency(item.product.price)}</td>
                  <td className="text-right py-2 font-semibold">
                    {formatCurrency(item.product.price * item.quantity)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="border-t border-gray-300 pt-4">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>{formatCurrency(transaction.subtotal)}</span>
            </div>
            <div className="flex justify-between text-green-600">
              <span>Discount:</span>
              <span>-{formatCurrency(transaction.discount)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t border-gray-300 pt-2">
              <span>Total:</span>
              <span>{formatCurrency(transaction.total)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-6 pt-4 border-t border-gray-200 text-sm text-gray-600">
          <p>Thank you for your business!</p>
          <p>Return Policy: 30 days with receipt</p>
        </div>
      </div>

      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <button
          onClick={onNewSale}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
        >
          <ArrowLeft className="w-5 h-5" />
          New Sale
        </button>
      </div>
    </div>
  );
};