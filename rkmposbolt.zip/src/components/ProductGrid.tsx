import React from 'react';
import { Product } from '../types';
import { Plus, Package } from 'lucide-react';
import { formatCurrency } from '../utils/currency';

interface ProductGridProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({ products, onAddToCart }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-200 hover:shadow-lg hover:scale-105 cursor-pointer"
          onClick={() => onAddToCart(product)}
        >
          <div className="relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            {product.stock <= 5 && (
              <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                Low Stock
              </div>
            )}
          </div>
          <div className="p-4">
            <h3 className="font-semibold text-gray-800 mb-1 line-clamp-2">{product.name}</h3>
            <p className="text-sm text-gray-600 mb-2 line-clamp-1">{product.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-xl font-bold text-blue-600">{formatCurrency(product.price)}</span>
              <div className="flex items-center text-sm text-gray-500">
                <Package className="w-4 h-4 mr-1" />
                <span>{product.stock}</span>
              </div>
            </div>
            <button className="w-full mt-3 bg-blue-600 text-white py-2 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors">
              <Plus className="w-4 h-4" />
              Add to Cart
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};