import React from 'react';
import { ViewMode } from '../types';
import { ShoppingBag, BarChart3, Package, Settings, Search, Users, Tag, Moon, Sun } from 'lucide-react';

interface HeaderProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentView, 
  onViewChange, 
  searchTerm, 
  onSearchChange,
  theme,
  onThemeToggle
}) => {
  const navItems = [
    { id: 'products' as ViewMode, name: 'Products', icon: ShoppingBag },
    { id: 'customers' as ViewMode, name: 'Customers', icon: Users },
    { id: 'categories' as ViewMode, name: 'Categories', icon: Tag },
    { id: 'reports' as ViewMode, name: 'Reports', icon: BarChart3 },
    { id: 'inventory' as ViewMode, name: 'Inventory', icon: Package },
    { id: 'settings' as ViewMode, name: 'Settings', icon: Settings },
  ];

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <ShoppingBag className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">RetailPOS</h1>
              <p className="text-xs text-gray-600">Point of Sale System</p>
            </div>
          </div>

          {/* Search Bar */}
          {currentView === 'products' && (
            <div className="flex-1 max-w-md mx-8">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex items-center gap-2">
            <button
              onClick={onThemeToggle}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                  currentView === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </button>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};