import React, { useState } from 'react';
import { CartItem, PaymentMethod, Transaction, Customer, DiscountType } from '../types';
import { CreditCard, Banknote, Smartphone, ArrowLeft, Receipt, UserPlus } from 'lucide-react';
import { formatCurrency } from '../utils/currency';

interface CheckoutProps {
  items: CartItem[];
  discount: DiscountType;
  customers: Customer[];
  onComplete: (transaction: Transaction) => void;
  onBack: () => void;
}

export const Checkout: React.FC<CheckoutProps> = ({ items, discount, customers, onComplete, onBack }) => {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [amountPaid, setAmountPaid] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountAmount = discount.type === 'percentage' 
    ? (subtotal * discount.value) / 100 
    : discount.value;
  const total = subtotal - discountAmount;
  const change = parseFloat(amountPaid) - total;

  const handlePayment = async () => {
    if (paymentMethod === 'cash' && parseFloat(amountPaid) < total) {
      alert('Insufficient payment amount');
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    const transaction: Transaction = {
      id: `TXN-${Date.now()}`,
      items,
      subtotal,
      discount: discountAmount,
      total,
      paymentMethod,
      timestamp: new Date(),
      customerName: selectedCustomer?.name,
      customerId: selectedCustomer?.id
    };

    onComplete(transaction);
    setIsProcessing(false);
  };

  const paymentMethods = [
    { id: 'card' as PaymentMethod, name: 'Credit/Debit Card', icon: CreditCard },
    { id: 'cash' as PaymentMethod, name: 'Cash', icon: Banknote },
    { id: 'digital' as PaymentMethod, name: 'Digital Wallet', icon: Smartphone },
    { id: 'credit' as PaymentMethod, name: 'Credit', icon: UserPlus },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-4 border-b border-gray-200 flex items-center gap-3">
        <button
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
          <Receipt className="w-6 h-6" />
          Checkout
        </h2>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Order Summary */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Order Summary</h3>
            <div className="space-y-3 mb-4">
              {items.map((item) => (
                <div key={item.product.id} className="flex justify-between items-center">
                  <div>
                    <span className="font-medium">{item.product.name}</span>
                    <span className="text-gray-600 ml-2">×{item.quantity}</span>
                  </div>
                  <span className="font-semibold">{formatCurrency(item.product.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-200 pt-4 space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal:</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Discount:</span>
                <span>-{formatCurrency(discountAmount)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-gray-800 pt-2 border-t border-gray-300">
                <span>Total:</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>
          </div>

          {/* Payment Details */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Payment Details</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Customer (Optional)
              </label>
              <select
                value={selectedCustomer?.id || ''}
                onChange={(e) => {
                  const customer = customers.find(c => c.id === e.target.value);
                  setSelectedCustomer(customer || null);
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Walk-in Customer</option>
                {customers.map((customer) => (
                  <option key={customer.id} value={customer.id}>
                    {customer.name} - {customer.phone}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Payment Method
              </label>
              <div className="grid grid-cols-1 gap-3">
                {paymentMethods.map((method) => (
                  <label
                    key={method.id}
                    className={`flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                      paymentMethod === method.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value={method.id}
                      checked={paymentMethod === method.id}
                      onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                      className="sr-only"
                    />
                    <method.icon className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">{method.name}</span>
                  </label>
                ))}
              </div>
            </div>

            {paymentMethod === 'cash' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Amount Paid
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0.00"
                />
                {amountPaid && change >= 0 && (
                  <p className="mt-2 text-sm text-green-600">
                    Change: {formatCurrency(change)}
                  </p>
                )}
              </div>
            )}

            <button
              onClick={handlePayment}
              disabled={isProcessing || (paymentMethod === 'cash' && (!amountPaid || parseFloat(amountPaid) < total))}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {isProcessing ? 'Processing...' : `Complete Payment (${formatCurrency(total)})`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};