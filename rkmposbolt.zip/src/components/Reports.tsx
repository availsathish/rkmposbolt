import React from 'react';
import { Transaction } from '../types';
import { TrendingUp, DollarSign, ShoppingCart, Users } from 'lucide-react';
import { formatCurrency } from '../utils/currency';

interface ReportsProps {
  transactions: Transaction[];
}

export const Reports: React.FC<ReportsProps> = ({ transactions }) => {
  const today = new Date();
  const todayTransactions = transactions.filter(
    t => t.timestamp.toDateString() === today.toDateString()
  );

  const totalRevenue = transactions.reduce((sum, t) => sum + t.total, 0);
  const todayRevenue = todayTransactions.reduce((sum, t) => sum + t.total, 0);
  const totalTransactions = transactions.length;
  const averageTransaction = totalRevenue / totalTransactions || 0;

  const stats = [
    {
      title: 'Total Revenue',
      value: formatCurrency(totalRevenue),
      icon: DollarSign,
      color: 'bg-green-500',
    },
    {
      title: "Today's Sales",
      value: formatCurrency(todayRevenue),
      icon: TrendingUp,
      color: 'bg-blue-500',
    },
    {
      title: 'Total Transactions',
      value: totalTransactions.toString(),
      icon: ShoppingCart,
      color: 'bg-purple-500',
    },
    {
      title: 'Average Transaction',
      value: formatCurrency(averageTransaction),
      icon: Users,
      color: 'bg-orange-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.title} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">Recent Transactions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left p-4">Transaction ID</th>
                <th className="text-left p-4">Date</th>
                <th className="text-left p-4">Customer</th>
                <th className="text-left p-4">Items</th>
                <th className="text-left p-4">Payment</th>
                <th className="text-right p-4">Total</th>
              </tr>
            </thead>
            <tbody>
              {transactions.slice(0, 10).map((transaction) => (
                <tr key={transaction.id} className="border-b border-gray-100">
                  <td className="p-4 font-mono text-xs">{transaction.id}</td>
                  <td className="p-4">{transaction.timestamp.toLocaleDateString()}</td>
                  <td className="p-4">{transaction.customerName || 'Guest'}</td>
                  <td className="p-4">{transaction.items.length} items</td>
                  <td className="p-4 capitalize">{transaction.paymentMethod}</td>
                  <td className="p-4 text-right font-semibold">{formatCurrency(transaction.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {transactions.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              No transactions yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
};