import React, { useState } from 'react';
import { Settings as SettingsType, BusinessInfo } from '../types';
import { Building, Palette, FileText, Trash2, Download, Upload } from 'lucide-react';

interface SettingsProps {
  settings: SettingsType;
  onUpdateSettings: (settings: SettingsType) => void;
  onDataReset: () => void;
  onDataExport: () => void;
}

export const Settings: React.FC<SettingsProps> = ({
  settings,
  onUpdateSettings,
  onDataReset,
  onDataExport,
}) => {
  const [activeTab, setActiveTab] = useState<'business' | 'appearance' | 'invoice' | 'data'>('business');
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>(settings.businessInfo);

  const handleBusinessInfoSave = () => {
    onUpdateSettings({
      ...settings,
      businessInfo
    });
  };

  const handleThemeChange = (theme: 'light' | 'dark') => {
    onUpdateSettings({
      ...settings,
      theme
    });
  };

  const handleInvoiceTemplateChange = (template: 'standard' | 'minimal' | 'detailed') => {
    onUpdateSettings({
      ...settings,
      invoiceTemplate: template
    });
  };

  const tabs = [
    { id: 'business' as const, name: 'Business Info', icon: Building },
    { id: 'appearance' as const, name: 'Appearance', icon: Palette },
    { id: 'invoice' as const, name: 'Invoice Template', icon: FileText },
    { id: 'data' as const, name: 'Data Management', icon: Download },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Settings</h2>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="bg-white rounded-lg shadow-md p-6">
        {activeTab === 'business' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-800">Business Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Business Name *
                </label>
                <input
                  type="text"
                  value={businessInfo.name}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter business name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone *
                </label>
                <input
                  type="tel"
                  value={businessInfo.phone}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="+91 9876543210"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Address *
                </label>
                <textarea
                  value={businessInfo.address}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter business address"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={businessInfo.email || ''}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="business@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  GST Number
                </label>
                <input
                  type="text"
                  value={businessInfo.gstNo || ''}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, gstNo: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="29ABCDE1234F1Z5"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Website
                </label>
                <input
                  type="url"
                  value={businessInfo.website || ''}
                  onChange={(e) => setBusinessInfo({ ...businessInfo, website: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="https://www.business.com"
                />
              </div>
            </div>
            <button
              onClick={handleBusinessInfoSave}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Save Business Info
            </button>
          </div>
        )}

        {activeTab === 'appearance' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-800">Appearance Settings</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Theme
              </label>
              <div className="grid grid-cols-2 gap-4 max-w-md">
                <button
                  onClick={() => handleThemeChange('light')}
                  className={`p-4 border-2 rounded-lg flex flex-col items-center gap-2 transition-colors ${
                    settings.theme === 'light'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <div className="w-12 h-8 bg-white border border-gray-300 rounded"></div>
                  <span className="text-sm font-medium">Light Mode</span>
                </button>
                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`p-4 border-2 rounded-lg flex flex-col items-center gap-2 transition-colors ${
                    settings.theme === 'dark'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <div className="w-12 h-8 bg-gray-800 border border-gray-600 rounded"></div>
                  <span className="text-sm font-medium">Dark Mode</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'invoice' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-800">Invoice Template</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Template
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { id: 'standard', name: 'Standard', description: 'Clean and professional layout' },
                  { id: 'minimal', name: 'Minimal', description: 'Simple and compact design' },
                  { id: 'detailed', name: 'Detailed', description: 'Comprehensive with extra fields' }
                ].map((template) => (
                  <button
                    key={template.id}
                    onClick={() => handleInvoiceTemplateChange(template.id as any)}
                    className={`p-4 border-2 rounded-lg text-left transition-colors ${
                      settings.invoiceTemplate === template.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <h4 className="font-medium text-gray-800">{template.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">{template.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'data' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-800">Data Management</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-medium text-gray-800 mb-2">Export Data</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Download all your data including products, customers, and transactions.
                </p>
                <button
                  onClick={onDataExport}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export All Data
                </button>
              </div>
              <div className="p-4 border border-red-200 rounded-lg bg-red-50">
                <h4 className="font-medium text-red-800 mb-2">Reset Data</h4>
                <p className="text-sm text-red-600 mb-4">
                  This will permanently delete all data. This action cannot be undone.
                </p>
                <button
                  onClick={() => {
                    if (confirm('Are you sure you want to reset all data? This action cannot be undone.')) {
                      onDataReset();
                    }
                  }}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Reset All Data
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};