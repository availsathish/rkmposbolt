import React from 'react';
import { CartItem, DiscountType } from '../types';
import { Minus, Plus, Trash2, ShoppingCart } from 'lucide-react';
import { formatCurrency } from '../utils/currency';

interface CartProps {
  items: CartItem[];
  discount: DiscountType;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onDiscountChange: (discount: DiscountType) => void;
  onCheckout: () => void;
}

export const Cart: React.FC<CartProps> = ({ 
  items, 
  discount, 
  onUpdateQuantity, 
  onRemoveItem, 
  onDiscountChange, 
  onCheckout 
}) => {
  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountAmount = discount.type === 'percentage' 
    ? (subtotal * discount.value) / 100 
    : discount.value;
  const total = subtotal - discountAmount;

  if (items.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 text-center">
        <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-600 mb-2">Cart is empty</h3>
        <p className="text-gray-500">Add some products to get started</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
          <ShoppingCart className="w-6 h-6" />
          Cart ({items.length} items)
        </h2>
      </div>
      
      <div className="max-h-96 overflow-y-auto">
        {items.map((item) => (
          <div key={item.product.id} className="p-4 border-b border-gray-100 last:border-b-0">
            <div className="flex items-center gap-3">
              <img
                src={item.product.image}
                alt={item.product.name}
                className="w-12 h-12 rounded object-cover"
              />
              <div className="flex-1">
                <h4 className="font-medium text-gray-800">{item.product.name}</h4>
                <p className="text-sm text-gray-600">{formatCurrency(item.product.price)} each</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                  className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300 transition-colors"
                  disabled={item.quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-8 text-center font-semibold">{item.quantity}</span>
                <button
                  onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                  className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onRemoveItem(item.product.id)}
                  className="w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center hover:bg-red-200 transition-colors ml-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="text-right mt-2">
              <span className="font-semibold text-blue-600">
                {formatCurrency(item.product.price * item.quantity)}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-gray-200 bg-gray-50">
        {/* Discount Section */}
        <div className="mb-4 p-3 bg-white rounded-lg border">
          <h4 className="font-medium text-gray-800 mb-2">Discount</h4>
          <div className="flex gap-2 mb-2">
            <select
              value={discount.type}
              onChange={(e) => onDiscountChange({ ...discount, type: e.target.value as 'percentage' | 'fixed' })}
              className="px-2 py-1 border border-gray-300 rounded text-sm"
            >
              <option value="percentage">%</option>
              <option value="fixed">₹</option>
            </select>
            <input
              type="number"
              value={discount.value}
              onChange={(e) => onDiscountChange({ ...discount, value: parseFloat(e.target.value) || 0 })}
              className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
              placeholder="0"
              min="0"
              max={discount.type === 'percentage' ? 100 : subtotal}
            />
          </div>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal:</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          <div className="flex justify-between text-green-600">
            <span>Discount:</span>
            <span>-{formatCurrency(discountAmount)}</span>
          </div>
          <div className="flex justify-between text-xl font-bold text-gray-800 pt-2 border-t border-gray-300">
            <span>Total:</span>
            <span>{formatCurrency(Math.max(0, total))}</span>
          </div>
        </div>
        <button
          onClick={onCheckout}
          disabled={items.length === 0 || total <= 0}
          className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
};