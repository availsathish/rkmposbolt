import { Product } from '../types';

export const sampleProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Headphones',
    price: 7499,
    category: 'Electronics',
    image: 'https://images.pexels.com/photos/3945667/pexels-photo-3945667.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 25,
    barcode: '1234567890123',
    description: 'High-quality wireless headphones with noise cancellation'
  },
  {
    id: '2',
    name: 'Cotton T-Shirt',
    price: 999,
    category: 'Clothing',
    image: 'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 50,
    barcode: '1234567890124',
    description: 'Comfortable 100% cotton t-shirt in various colors'
  },
  {
    id: '3',
    name: 'Coffee Beans',
    price: 549,
    category: 'Food & Drink',
    image: 'https://images.pexels.com/photos/894695/pexels-photo-894695.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 100,
    barcode: '1234567890125',
    description: 'Premium arabica coffee beans, medium roast'
  },
  {
    id: '4',
    name: 'Programming Book',
    price: 1599,
    category: 'Books',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 15,
    barcode: '1234567890126',
    description: 'Comprehensive guide to modern programming practices'
  },
  {
    id: '5',
    name: 'Plant Pot',
    price: 799,
    category: 'Home & Garden',
    image: 'https://images.pexels.com/photos/1005058/pexels-photo-1005058.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 30,
    barcode: '1234567890127',
    description: 'Ceramic plant pot with drainage holes'
  },
  {
    id: '6',
    name: 'Yoga Mat',
    price: 1499,
    category: 'Sports',
    image: 'https://images.pexels.com/photos/3820295/pexels-photo-3820295.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 20,
    barcode: '1234567890128',
    description: 'Non-slip yoga mat with carrying strap'
  },
  {
    id: '7',
    name: 'Smartphone Case',
    price: 899,
    category: 'Electronics',
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 75,
    barcode: '1234567890129',
    description: 'Protective smartphone case with screen protector'
  },
  {
    id: '8',
    name: 'Denim Jeans',
    price: 2499,
    category: 'Clothing',
    image: 'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=300',
    stock: 35,
    barcode: '1234567890130',
    description: 'Classic fit denim jeans in multiple sizes'
  }
];