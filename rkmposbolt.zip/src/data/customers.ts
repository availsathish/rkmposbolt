import { Customer } from '../types';

export const sampleCustomers: Customer[] = [
  {
    id: '1',
    name: 'Rajesh Kumar',
    phone: '+91 9876543210',
    email: 'rajesh.kumar@email.com',
    address: '123 MG Road, Bangalore',
    gstNo: '29ABCDE1234F1Z5',
    area: 'MG Road',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    name: 'Priya Sharma',
    phone: '+91 8765432109',
    email: 'priya.sharma@email.com',
    address: '456 Connaught Place, Delhi',
    area: 'Connaught Place',
    createdAt: new Date('2024-02-10')
  },
  {
    id: '3',
    name: 'Amit Patel',
    phone: '+91 7654321098',
    address: '789 Marine Drive, Mumbai',
    gstNo: '27FGHIJ5678K2L6',
    area: 'Marine Drive',
    createdAt: new Date('2024-03-05')
  }
];