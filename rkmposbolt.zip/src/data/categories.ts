import { Category } from '../types';

export const defaultCategories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    description: 'Electronic devices and accessories',
    isActive: true
  },
  {
    id: '2',
    name: 'Clothing',
    description: 'Apparel and fashion items',
    isActive: true
  },
  {
    id: '3',
    name: 'Food & Drink',
    description: 'Food items and beverages',
    isActive: true
  },
  {
    id: '4',
    name: 'Books',
    description: 'Books and educational materials',
    isActive: true
  },
  {
    id: '5',
    name: 'Home & Garden',
    description: 'Home improvement and garden items',
    isActive: true
  },
  {
    id: '6',
    name: 'Sports',
    description: 'Sports equipment and accessories',
    isActive: true
  }
];