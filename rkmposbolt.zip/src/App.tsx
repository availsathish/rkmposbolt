import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { CategoryFilter } from './components/CategoryFilter';
import { ProductGrid } from './components/ProductGrid';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { Receipt } from './components/Receipt';
import { Reports } from './components/Reports';
import { Inventory } from './components/Inventory';
import { Categories } from './components/Categories';
import { Customers } from './components/Customers';
import { Settings } from './components/Settings';
import { sampleProducts } from './data/products';
import { defaultCategories } from './data/categories';
import { sampleCustomers } from './data/customers';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Product, CartItem, Transaction, ViewMode, Category, Customer, DiscountType, Settings as SettingsType } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('products');
  const [products, setProducts] = useLocalStorage<Product[]>('pos-products', sampleProducts);
  const [categories, setCategories] = useLocalStorage<Category[]>('pos-categories', defaultCategories);
  const [rawCustomers, setRawCustomers] = useLocalStorage<Customer[]>('pos-customers', sampleCustomers);
  const [rawTransactions, setRawTransactions] = useLocalStorage<Transaction[]>('pos-transactions', []);
  const [settings, setSettings] = useLocalStorage<SettingsType>('pos-settings', {
    theme: 'light',
    businessInfo: {
      name: 'RetailPOS',
      address: '123 Main Street, City, State 12345',
      phone: '+91 9876543210',
      email: 'info@retailpos.com',
      gstNo: '29ABCDE1234F1Z5'
    },
    invoiceTemplate: 'standard'
  });
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null);
  const [discount, setDiscount] = useState<DiscountType>({ type: 'percentage', value: 0 });

  // Convert string dates back to Date objects
  const customers = useMemo(() => {
    return rawCustomers.map(customer => ({
      ...customer,
      createdAt: typeof customer.createdAt === 'string' ? new Date(customer.createdAt) : customer.createdAt
    }));
  }, [rawCustomers]);

  const transactions = useMemo(() => {
    return rawTransactions.map(transaction => ({
      ...transaction,
      timestamp: typeof transaction.timestamp === 'string' ? new Date(transaction.timestamp) : transaction.timestamp
    }));
  }, [rawTransactions]);

  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.description?.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchTerm, categories]);

  const addToCart = (product: Product) => {
    setCartItems(current => {
      const existingItem = current.find(item => item.product.id === product.id);
      if (existingItem) {
        return current.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...current, { product, quantity: 1 }];
    });
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(current =>
      current.map(item =>
        item.product.id === productId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCartItems(current => current.filter(item => item.product.id !== productId));
  };

  const handleCheckout = () => {
    setCurrentView('checkout');
  };

  const handleTransactionComplete = (transaction: Transaction) => {
    setRawTransactions(current => [transaction, ...current]);
    setCurrentTransaction(transaction);
    setCartItems([]);
    setDiscount({ type: 'percentage', value: 0 });
    
    // Update product stock
    setProducts(current =>
      current.map(product => {
        const cartItem = transaction.items.find(item => item.product.id === product.id);
        if (cartItem) {
          return { ...product, stock: product.stock - cartItem.quantity };
        }
        return product;
      })
    );
    
    setCurrentView('receipt');
  };

  const handleNewSale = () => {
    setCurrentTransaction(null);
    setCurrentView('products');
  };

  const handleBackToProducts = () => {
    setCurrentView('products');
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(current =>
      current.map(product =>
        product.id === updatedProduct.id ? updatedProduct : product
      )
    );
  };

  const handleAddProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
    };
    setProducts(current => [...current, newProduct]);
  };

  const handleDeleteProduct = (productId: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      setProducts(current => current.filter(product => product.id !== productId));
      removeFromCart(productId);
    }
  };

  const handleUpdateCategory = (updatedCategory: Category) => {
    setCategories(current =>
      current.map(category =>
        category.id === updatedCategory.id ? updatedCategory : category
      )
    );
  };

  const handleAddCategory = (categoryData: Omit<Category, 'id'>) => {
    const newCategory: Category = {
      ...categoryData,
      id: Date.now().toString(),
    };
    setCategories(current => [...current, newCategory]);
  };

  const handleDeleteCategory = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (category && !category.isActive) {
      if (confirm('Are you sure you want to delete this category?')) {
        setCategories(current => current.filter(category => category.id !== categoryId));
      }
    }
  };

  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setRawCustomers(current =>
      current.map(customer =>
        customer.id === updatedCustomer.id ? updatedCustomer : customer
      )
    );
  };

  const handleAddCustomer = (customerData: Omit<Customer, 'id' | 'createdAt'>) => {
    const newCustomer: Customer = {
      ...customerData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setRawCustomers(current => [...current, newCustomer]);
  };

  const handleDeleteCustomer = (customerId: string) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      setRawCustomers(current => current.filter(customer => customer.id !== customerId));
    }
  };

  const handleDataReset = () => {
    setProducts(sampleProducts);
    setCategories(defaultCategories);
    setRawCustomers(sampleCustomers);
    setRawTransactions([]);
    setCartItems([]);
    setDiscount({ type: 'percentage', value: 0 });
  };

  const handleDataExport = () => {
    const data = {
      products,
      categories,
      customers: rawCustomers,
      transactions: rawTransactions,
      settings,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pos-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleThemeToggle = () => {
    setSettings(current => ({
      ...current,
      theme: current.theme === 'light' ? 'dark' : 'light'
    }));
  };
  const renderContent = () => {
    switch (currentView) {
      case 'checkout':
        return (
          <Checkout
            items={cartItems}
            discount={discount}
            customers={customers}
            onComplete={handleTransactionComplete}
            onBack={handleBackToProducts}
          />
        );
      case 'receipt':
        return currentTransaction ? (
          <Receipt
            transaction={currentTransaction}
            settings={settings}
            onNewSale={handleNewSale}
          />
        ) : null;
      case 'reports':
        return <Reports transactions={transactions} />;
      case 'inventory':
        return (
          <Inventory
            products={products}
            categories={categories}
            onUpdateProduct={handleUpdateProduct}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
      case 'categories':
        return (
          <Categories
            categories={categories}
            onUpdateCategory={handleUpdateCategory}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
          />
        );
      case 'customers':
        return (
          <Customers
            customers={customers}
            onUpdateCustomer={handleUpdateCustomer}
            onAddCustomer={handleAddCustomer}
            onDeleteCustomer={handleDeleteCustomer}
          />
        );
      case 'settings':
        return (
          <Settings
            settings={settings}
            onUpdateSettings={setSettings}
            onDataReset={handleDataReset}
            onDataExport={handleDataExport}
          />
        );
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3 space-y-4">
              <CategoryFilter
                categories={categories}
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
              />
              <ProductGrid products={filteredProducts} onAddToCart={addToCart} />
            </div>
            <div className="lg:col-span-1">
              <Cart
                items={cartItems}
                discount={discount}
                onUpdateQuantity={updateCartQuantity}
                onRemoveItem={removeFromCart}
                onDiscountChange={setDiscount}
                onCheckout={handleCheckout}
              />
            </div>
          </div>
        );
    }
  };

  return (
    <div className={`min-h-screen ${settings.theme === 'dark' ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        theme={settings.theme}
        onThemeToggle={handleThemeToggle}
      />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;