export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  stock: number;
  barcode?: string;
  description?: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Transaction {
  id: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  timestamp: Date;
  customerName?: string;
  customerId?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  gstNo?: string;
  area?: string;
  createdAt: Date;
}

export interface BusinessInfo {
  name: string;
  logo?: string;
  address: string;
  phone: string;
  email?: string;
  gstNo?: string;
  website?: string;
}

export interface Settings {
  theme: 'light' | 'dark';
  businessInfo: BusinessInfo;
  invoiceTemplate: 'standard' | 'minimal' | 'detailed';
}

export type PaymentMethod = 'cash' | 'card' | 'digital' | 'credit';

export type ViewMode = 'products' | 'checkout' | 'receipt' | 'reports' | 'inventory' | 'customers' | 'categories' | 'settings';

export interface DiscountType {
  type: 'percentage' | 'fixed';
  value: number;
}